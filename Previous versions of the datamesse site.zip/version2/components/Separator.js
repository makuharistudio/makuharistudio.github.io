import React from 'react';
import '../App.css';

function Separator() {
    return (
            <center>
                <div className='separator'></div>
            </center>
        );
}

export default Separator;