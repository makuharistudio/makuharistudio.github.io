# ABOUT

Pending the ability to describe myself.

## LinkedIn Skill Assessment Badges
Please visit my LinkedIn profile's Skills section for more information.

### XML
* Top **15%** of **203.0 thousand** people who took this test, badge earned 5th May 2022
### Microsoft Transact-SQL (T-SQL)
* Top **30%** of **323.1 thousand** people who took this test, badge earned 27th August 2021
### Microsoft Power BI
* Top **15%** of **506.6 thousand** people who took this test, badge earned 27th August 2021
### HTML
* Top **30%** of **2.7 million** people who took this test, badge earned 10th September 2020
### CSS
* Top **15%** of **1.4 million** people who took this test, badge earned 10th September 2020
### JavaScript
* **Top 5%** of **1.8 million** people who took this test, badge earned 10th May 2020
### Microsoft Excel
* Top **5%** of **21.4 million** people who took this test, badge earned 30th October 2019

# _  _  _

**How are LinkedIn Skill Assessments made and scored?**

[https://www.linkedin.com/help/linkedin/answer/a507663](https://www.linkedin.com/help/linkedin/answer/a507663)

**What are the available LinkedIn Skill Assessments?**

[https://www.linkedin.com/help/linkedin/answer/a507734](https://www.linkedin.com/help/linkedin/answer/a507734)