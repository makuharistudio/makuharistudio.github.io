import React from 'react';
import '../App.css';
import Menu from './Menu';

function Footer() {

    return (

        <>
            <div className='bg-footer'>

                <Menu />

            </div>
        </>

    );
}

export default Footer;